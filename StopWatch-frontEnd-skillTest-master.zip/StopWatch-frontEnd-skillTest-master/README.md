# STOPWATCH
# STOPWATCH (Made using HTML5 CSS3 and JavaScript)
site is live at https://khushbookachhi.github.io/StopWatch-frontEnd-skillTest/

ABOUT THIS PROJECT-:

1.In this project i have created a simple stopwatch using HTML CSS and JavaScript.

2.In the Stopwatch there are three buttons start, pause, and reset for operating the stopwatch.

3.The main logic use in this stopwatch project is the set timeout function.
